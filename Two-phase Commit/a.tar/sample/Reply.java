import java.io.Serializable;

public class Reply implements Serializable {
    String filename;
    boolean agree;
    public Reply(String filename, boolean agree) {
        this.filename = filename;
        this.agree = agree;
    }
}
