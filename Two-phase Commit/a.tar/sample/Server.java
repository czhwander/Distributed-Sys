/* Skeleton code for Server */

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Server implements ProjectLib.CommitServing {
	private static ProjectLib PL;
	private static Map<String, Collage> collages;

	public void startCommit( String filename, byte[] img, String[] sources ) {
		Collage collage = new Collage(filename, img, sources);
		startVote(collage);
	}

	private void startVote(Collage collage) {
		collages.put(collage.filename, collage);
		for (String addr : collage.sources.keySet()) {
			try {
				ProjectLib.Message msg = new ProjectLib.Message(addr, Serilize.serilize(collage));
				PL.sendMessage(msg);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private static void announceDelete(Collage collage) throws IOException {
		collage.save();
		collages.remove(collage.filename);
		for (String addr : collage.sources.keySet()) {
			StringBuilder toDelete = new StringBuilder();
			for (String filename : collage.sources.get(addr)){
				toDelete.append(filename).append(" ");
			}
			ProjectLib.Message msg = new ProjectLib.Message(addr, toDelete.substring(0, toDelete.length() - 1).getBytes());
			PL.sendMessage(msg);
		}
	}
	
	public static void main ( String args[] ) throws Exception {
		if (args.length != 1) throw new Exception("Need 1 arg: <port>");
		Server srv = new Server();
		PL = new ProjectLib( Integer.parseInt(args[0]), srv );
		collages = new HashMap<>();
		// main loop
		while (true) {
			ProjectLib.Message msg = PL.getMessage();
			Reply reply = (Reply) Serilize.deserilize(msg.body);
			if (reply.agree) {
				Collage collage = collages.get(reply.filename);
				collage.votes++;
				if (collage.votes == collage.sources.size()) {
					announceDelete(collage);
				}
			} else {
			}
		}
	}
}

