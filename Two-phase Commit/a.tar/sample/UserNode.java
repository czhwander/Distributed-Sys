/* Skeleton code for UserNode */

import java.io.File;
import java.io.IOException;

public class UserNode implements ProjectLib.MessageHandling {
	private final String myId;

	private static ProjectLib PL;

	public UserNode( String id ) {
		myId = id;
	}

	public boolean deliverMessage( ProjectLib.Message msg ) {
		try {
			Object object = Serilize.deserilize(msg.body);
			if (object.getClass().equals(Collage.class)) {
				vote((Collage) object, msg.addr);
			} else {
				delete((String) object);
			}
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return true;
	}

	private void delete(String src) {
		for (String filename : src.split(" ")) {
			File file = new File(filename);
			if (file.exists()) {
				file.delete();
			}
		}
	}

	private void vote(Collage collage, String addr) throws IOException {
		String[] sources = (String[]) collage.sources.get(myId).toArray();
		boolean result = PL.askUser(collage.img, sources);

		Reply reply = new Reply(collage.filename, result);
		ProjectLib.Message msg = new ProjectLib.Message(addr, Serilize.serilize(reply));
		PL.sendMessage(msg);
	}
	
	public static void main ( String args[] ) throws Exception {
		if (args.length != 2) throw new Exception("Need 2 args: <port> <id>");
		UserNode UN = new UserNode(args[1]);
		PL = new ProjectLib( Integer.parseInt(args[0]), args[1], UN );

		ProjectLib.Message msg = new ProjectLib.Message( "Server", "hello".getBytes() );
		System.out.println( args[1] + ": Sending message to " + msg.addr );
		PL.sendMessage( msg );
	}
}

