import java.io.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Collage implements Serializable{
    String filename;
    int votes;
    byte[] img;
    Map<String, Set<String>> sources;

    public Collage(String filename, byte[] img, String[] sources) {
        this.sources = new HashMap<>();
        this.filename = filename;
        this.img = img;
        this.votes = 0;
        String[] tem;
        for (String s : sources) {
            tem = s.split(":");
            this.sources.putIfAbsent(tem[0], new HashSet<>());
            this.sources.get(tem[0]).add(tem[1]);
        }
    }

    public void save() throws IOException {
        File file = new File(filename);
        RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");
        randomAccessFile.write(img);
        randomAccessFile.close();
    }
}
